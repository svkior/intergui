(function(){/**
 * Created by svkior on 27/08/14.
 */
Firmwares = new Meteor.Collection('firmwares');

})();
